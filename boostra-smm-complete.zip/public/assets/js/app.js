async function api(url,options={}) {
  const r=await fetch(url,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||"Request failed");
  return data;
}
function money(v){return "₦"+Number(v||0).toLocaleString("en-NG",{minimumFractionDigits:2,maximumFractionDigits:2});}
document.addEventListener("DOMContentLoaded",()=>{
  const b=document.getElementById("menuBtn");
  if(b)b.onclick=()=>document.querySelector(".layout").classList.toggle("open");
  const l=document.getElementById("logoutBtn");
  if(l)l.onclick=async()=>{await api("/api/auth/logout",{method:"POST"});location.href="/login.html";};
  const l2=document.getElementById("logoutBtn2");
  if(l2)l2.onclick=async()=>{await api("/api/auth/logout",{method:"POST"});location.href="/login.html";};
});
