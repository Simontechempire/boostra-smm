async function loadDashboard(){
  try{
    const m=await api("/api/auth/me");
    const u=m.user;
    document.getElementById("username")?.replaceChildren(document.createTextNode(u.username));
    const w=await api("/api/wallet");
    const b=document.getElementById("balance");if(b)b.textContent=money(w.balance);
    const o=await api("/api/orders");
    const oc=document.getElementById("ordersCount");if(oc)oc.textContent=o.orders.length;
    const sc=document.getElementById("serviceCards");
    if(sc)sc.innerHTML=(await api("/api/services")).services.slice(0,9).map(s=>`<article class="service-card"><b>${escapeHtml(s.name)}</b><p>${escapeHtml(s.category)}</p><strong>${money(s.rate)} / 1000</strong></article>`).join("");
    if(document.getElementById("account"))document.getElementById("account").innerHTML=`<p><b>${escapeHtml(u.first_name)} ${escapeHtml(u.last_name)}</b></p><p>${escapeHtml(u.email)}</p><p>WhatsApp: ${escapeHtml(u.whatsapp||"-")}</p>`;
    if(document.getElementById("ordersList"))document.getElementById("ordersList").innerHTML=o.orders.map(x=>`<div class="table-row"><span>#${x.id}</span><span>${escapeHtml(x.service_name||"Service")}</span><span>${x.status}</span><span>${money(x.charge)}</span></div>`).join("")||"<p>No orders yet.</p>";
  }catch(e){if(e.message.includes("Authentication"))location.href="/login.html";}
}
async function loadServices(){
  const box=document.getElementById("servicesList");if(!box)return;
  const data=await api("/api/services");
  const render=()=>{const q=(document.getElementById("search")?.value||"").toLowerCase();box.innerHTML=data.services.filter(s=>s.name.toLowerCase().includes(q)||s.category.toLowerCase().includes(q)).map(s=>`<div class="table-row"><span>${escapeHtml(s.name)}</span><span>${escapeHtml(s.category)}</span><span>${money(s.rate)}/1000</span><span>${s.min_quantity}-${s.max_quantity}</span></div>`).join("")};
  document.getElementById("search")?.addEventListener("input",render);render();
}
async function loadNewOrder(){
  const s=document.getElementById("service");if(!s)return;
  const data=await api("/api/services");
  s.innerHTML=data.services.map(x=>`<option value="${x.id}" data-rate="${x.rate}" data-min="${x.min_quantity}" data-max="${x.max_quantity}" data-desc="${escapeAttr(x.description||"")}">${escapeHtml(x.name)} — ${money(x.rate)}/1000</option>`).join("");
  const update=()=>{const x=s.selectedOptions[0];const q=Number(document.getElementById("quantity").value||0);document.getElementById("description").textContent=x?.dataset.desc||"";document.getElementById("charge").textContent=money(Number(x?.dataset.rate||0)*q/1000);};
  s.onchange=update;document.getElementById("quantity").oninput=update;update();
  document.getElementById("submitOrder").onclick=async()=>{try{const r=await api("/api/orders",{method:"POST",body:JSON.stringify({serviceId:Number(s.value),link:document.getElementById("link").value,quantity:Number(document.getElementById("quantity").value)})});alert(r.message);location.href="/orders.html";}catch(e){alert(e.message);}};
}
async function loadFunds(){
  const f=document.getElementById("fundForm");if(!f)return;
  f.onsubmit=async e=>{e.preventDefault();try{const r=await api("/api/payments",{method:"POST",body:JSON.stringify({amount:Number(document.getElementById("fundAmount").value)})});document.getElementById("paymentInfo").innerHTML=`<div class="panel"><b>Payment reference:</b> ${r.payment.reference}<p>Transfer ₦${Number(r.payment.amount).toFixed(2)} to <b>${r.instructions.bank}</b><br>Account: <b>${r.instructions.accountName}</b><br>Number: <b>${r.instructions.accountNumber}</b></p><p>After transfer, contact support with your reference.</p></div>`;}catch(e){alert(e.message);}};
}
async function loadAffiliate(){try{const r=await api("/api/affiliates");document.getElementById("refCode").textContent=r.referralCode;document.getElementById("refTotal").textContent=r.total;document.getElementById("refRewards").textContent=money(r.rewards);}catch(e){}}
async function loadTickets(){
  const box=document.getElementById("ticketsList");if(!box)return;
  const render=async()=>{const r=await api("/api/tickets");box.innerHTML=r.tickets.map(t=>`<div class="panel"><b>${escapeHtml(t.subject)}</b><p>${escapeHtml(t.message)}</p><small>${t.status}</small></div>`).join("")};
  document.getElementById("ticketForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/tickets",{method:"POST",body:JSON.stringify({subject:document.getElementById("subject").value,message:document.getElementById("message").value})});e.target.reset();render();}catch(x){alert(x.message)}};render();
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function escapeAttr(v){return escapeHtml(v).replace(/`/g,"&#96;");}
document.addEventListener("DOMContentLoaded",()=>{loadDashboard();loadServices();loadNewOrder();loadFunds();loadAffiliate();loadTickets();});
