const $=s=>document.querySelector(s);
function show(msg){const el=$("#msg");if(el)el.textContent=msg;}

$("#signupForm")?.addEventListener("submit",async e=>{
  e.preventDefault();
  const f=new FormData(e.target), body=Object.fromEntries(f.entries());
  try{const r=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
    const d=await r.json(); if(!r.ok)throw new Error(d.error); location.href=d.redirect||"/verify-email.html";
  }catch(x){show(x.message);}
});

$("#verifyForm")?.addEventListener("submit",async e=>{
  e.preventDefault();const code=new FormData(e.target).get("code");
  try{const r=await fetch("/api/auth/verify-email",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});const d=await r.json();if(!r.ok)throw new Error(d.error);location.href=d.redirect;}
  catch(x){show(x.message);}
});

$("#resend")?.addEventListener("click",async()=>{
  try{const r=await fetch("/api/auth/resend-code",{method:"POST"});const d=await r.json();if(!r.ok)throw new Error(d.error);show(d.message);}
  catch(x){show(x.message);}
});

$("#loginForm")?.addEventListener("submit",async e=>{
  e.preventDefault();const body=Object.fromEntries(new FormData(e.target).entries());
  try{const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();if(!r.ok){if(d.redirect)location.href=d.redirect;throw new Error(d.error);}location.href=d.redirect;}
  catch(x){show(x.message);}
});

$("#forgotForm")?.addEventListener("submit",async e=>{
  e.preventDefault();const body=Object.fromEntries(new FormData(e.target).entries());
  try{const r=await fetch("/api/auth/forgot-password",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw new Error(d.error);show(d.message);}
  catch(x){show(x.message);}
});

$("#resetForm")?.addEventListener("submit",async e=>{
  e.preventDefault();const body=Object.fromEntries(new FormData(e.target).entries());
  body.token=new URLSearchParams(location.search).get("token");
  try{const r=await fetch("/api/auth/reset-password",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw new Error(d.error);show(d.message);setTimeout(()=>location.href=d.redirect,900);}
  catch(x){show(x.message);}
});
