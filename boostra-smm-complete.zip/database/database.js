const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");
const config = require("../server/config");

const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});

async function query(text, params = []) {
  return pool.query(text, params);
}

async function initDb() {
  if (!config.databaseUrl) throw new Error("DATABASE_URL is required.");
  const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  await pool.query(schema);
  await pool.query(`
    INSERT INTO settings(key,value) VALUES
      ('referral_reward','0'),
      ('currency','NGN')
    ON CONFLICT (key) DO NOTHING
  `);
}

module.exports = { pool, query, initDb };
