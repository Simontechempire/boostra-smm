const {query}=require("../../database/database");

async function createReferralIfNeeded(userId,code){
  if(!code) return;
  const r=await query("SELECT id FROM users WHERE referral_code=$1",[code]);
  if(!r.rows[0] || Number(r.rows[0].id)===Number(userId)) return;
  await query("UPDATE users SET referred_by=$1 WHERE id=$2 AND referred_by IS NULL",[r.rows[0].id,userId]);
  await query(
    "INSERT INTO referrals(referrer_id,referred_user_id) VALUES($1,$2) ON CONFLICT(referred_user_id) DO NOTHING",
    [r.rows[0].id,userId]
  );
}
module.exports={createReferralIfNeeded};
