const axios=require("axios");
const config=require("../config");

/*
 * Keep the provider integration isolated here.
 * Do not invent undocumented provider parameters.
 * Match this adapter to the exact API documentation/account response
 * before enabling real provider orders.
 */

async function request(params){
  if(!config.famsup.apiKey) throw new Error("FAMSUP_API_KEY is not configured.");
  const r=await axios.post(config.famsup.apiUrl,
    {key:config.famsup.apiKey,...params},
    {timeout:20000}
  );
  return r.data;
}

async function getServices(){ return request({action:"services"}); }
async function createOrder(service,link,quantity){ return request({action:"add",service,link,quantity}); }
async function getOrderStatus(order){ return request({action:"status",order}); }

module.exports={getServices,createOrder,getOrderStatus};
