const nodemailer = require("nodemailer");
const config = require("../config");

function transporter() {
  if (!config.smtp.host || !config.smtp.user || !config.smtp.pass)
    throw new Error("SMTP is not configured.");
  return nodemailer.createTransport({
    host:config.smtp.host,
    port:config.smtp.port,
    secure:config.smtp.secure,
    auth:{user:config.smtp.user,pass:config.smtp.pass}
  });
}

async function sendVerificationEmail(to,code) {
  await transporter().sendMail({
    from:config.smtp.from,
    to,
    subject:"Boostra SMM verification code",
    text:`Your Boostra verification code is ${code}. It expires in 10 minutes.`,
    html:`<h2>Boostra SMM</h2><p>Your verification code:</p><h1>${code}</h1><p>Expires in 10 minutes.</p>`
  });
}

async function sendPasswordResetEmail(to,url) {
  await transporter().sendMail({
    from:config.smtp.from,
    to,
    subject:"Boostra SMM password reset",
    text:`Reset your password: ${url}`,
    html:`<p>Reset your Boostra password:</p><p><a href="${url}">${url}</a></p>`
  });
}

module.exports={sendVerificationEmail,sendPasswordResetEmail};
