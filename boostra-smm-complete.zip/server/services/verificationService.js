const bcrypt=require("bcryptjs");
const {query}=require("../../database/database");
const {verificationCode}=require("../utils/generateCode");
const {sendVerificationEmail}=require("./emailService");

async function createVerification(userId,email){
  const code=verificationCode();
  const codeHash=await bcrypt.hash(code,10);
  await query("DELETE FROM email_verifications WHERE user_id=$1",[userId]);
  await query(
    "INSERT INTO email_verifications(user_id,code_hash,expires_at) VALUES($1,$2,NOW()+INTERVAL '10 minutes')",
    [userId,codeHash]
  );
  await sendVerificationEmail(email,code);
}

async function verifyCode(userId,code){
  const r=await query(
    "SELECT * FROM email_verifications WHERE user_id=$1 AND expires_at>NOW() ORDER BY created_at DESC LIMIT 1",
    [userId]
  );
  if(!r.rows[0] || r.rows[0].attempts>=5) return false;
  await query("UPDATE email_verifications SET attempts=attempts+1 WHERE id=$1",[r.rows[0].id]);
  if(!(await bcrypt.compare(code,r.rows[0].code_hash))) return false;
  await query("UPDATE users SET email_verified=true,updated_at=NOW() WHERE id=$1",[userId]);
  await query("DELETE FROM email_verifications WHERE user_id=$1",[userId]);
  return true;
}
module.exports={createVerification,verifyCode};
