const {query}=require("../../database/database");
const {credit}=require("./walletController");

async function listPending(req,res){
  const r=await query(
    `SELECT p.*,u.username,u.email FROM payments p
     JOIN users u ON u.id=p.user_id
     WHERE p.status='pending' ORDER BY p.created_at ASC`
  );
  res.json({payments:r.rows});
}

async function review(req,res){
  const id=Number(req.params.id);
  const action=req.body.action;
  if(!["approve","reject"].includes(action)) return res.status(400).json({error:"Invalid action."});

  const client=require("../../database/database").pool;
  const c=await client.connect();
  try{
    await c.query("BEGIN");
    const r=await c.query("SELECT * FROM payments WHERE id=$1 FOR UPDATE",[id]);
    if(!r.rows[0]) throw new Error("Payment not found.");
    const p=r.rows[0];
    if(p.status!=="pending") throw new Error("Payment already reviewed.");

    if(action==="approve"){
      const u=await c.query("SELECT balance FROM users WHERE id=$1 FOR UPDATE",[p.user_id]);
      const next=Number(u.rows[0].balance)+Number(p.amount);
      await c.query("UPDATE users SET balance=$1,updated_at=NOW() WHERE id=$2",[next.toFixed(2),p.user_id]);
      await c.query(
        "INSERT INTO wallet_transactions(user_id,type,amount,balance_after,reference,description) VALUES($1,'credit',$2,$3,$4,$5)",
        [p.user_id,p.amount,next.toFixed(2),p.reference,"Manual payment approved"]
      );
      await c.query("UPDATE payments SET status='approved',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",[req.session.ownerUserId,id]);
    }else{
      await c.query("UPDATE payments SET status='rejected',reviewed_by=$1,reviewed_at=NOW() WHERE id=$2",[req.session.ownerUserId,id]);
    }
    await c.query("COMMIT");
    res.json({message:`Payment ${action}d.`});
  }catch(e){
    await c.query("ROLLBACK");
    res.status(400).json({error:e.message});
  }finally{c.release();}
}

module.exports={listPending,review};
