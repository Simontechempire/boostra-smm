const bcrypt=require("bcryptjs");
const crypto=require("crypto");
const {query}=require("../../database/database");
const {createVerification,verifyCode}=require("../services/verificationService");
const {sendPasswordResetEmail}=require("../services/emailService");
const {randomToken,hash}=require("../utils/generateCode");
const {createReferralIfNeeded}=require("../services/referralService");

function safe(u){
  return {id:u.id,username:u.username,email:u.email,firstName:u.first_name,lastName:u.last_name,
    whatsapp:u.whatsapp,emailVerified:u.email_verified,balance:u.balance,status:u.status,referralCode:u.referral_code};
}

async function register(req,res){
  try{
    const {username,email,firstName,lastName,whatsapp,password,confirmPassword,referralCode}=req.body;
    if(!username||!email||!firstName||!lastName||!password) return res.status(400).json({error:"Complete all required fields."});
    if(password!==confirmPassword) return res.status(400).json({error:"Passwords do not match."});
    if(password.length<8) return res.status(400).json({error:"Password must be at least 8 characters."});
    const e=await query("SELECT id FROM users WHERE LOWER(email)=LOWER($1) OR LOWER(username)=LOWER($2)",[email.trim(),username.trim()]);
    if(e.rows[0]) return res.status(409).json({error:"Email or username already exists."});
    const ph=await bcrypt.hash(password,12);
    const referral=crypto.randomBytes(5).toString("hex");
    const r=await query(
      `INSERT INTO users(username,email,first_name,last_name,whatsapp,password_hash,referral_code)
       VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [username.trim(),email.trim().toLowerCase(),firstName.trim(),lastName.trim(),whatsapp||null,ph,referral]
    );
    await createReferralIfNeeded(r.rows[0].id,referralCode);
    await createVerification(r.rows[0].id,r.rows[0].email);
    req.session.userId=r.rows[0].id;
    req.session.emailVerified=false;
    res.json({message:"Account created. Check your email for the verification code.",redirect:"/verify-email.html"});
  }catch(e){console.error(e);res.status(500).json({error:"Registration failed. Check server logs."});}
}

async function verifyEmail(req,res){
  if(!req.session.userId) return res.status(401).json({error:"Verification session expired."});
  const ok=await verifyCode(req.session.userId,String(req.body.code||"").trim());
  if(!ok) return res.status(400).json({error:"Invalid or expired code."});
  req.session.emailVerified=true;
  res.json({message:"Email verified.",redirect:"/dashboard.html"});
}

async function resendCode(req,res){
  if(!req.session.userId) return res.status(401).json({error:"Session expired."});
  const r=await query("SELECT email FROM users WHERE id=$1",[req.session.userId]);
  if(!r.rows[0]) return res.status(404).json({error:"User not found."});
  await createVerification(req.session.userId,r.rows[0].email);
  res.json({message:"Verification code resent."});
}

async function login(req,res){
  const id=String(req.body.identifier||"").trim();
  const r=await query("SELECT * FROM users WHERE LOWER(email)=LOWER($1) OR LOWER(username)=LOWER($1) LIMIT 1",[id]);
  const u=r.rows[0];
  if(!u || !u.password_hash || !(await bcrypt.compare(req.body.password||"",u.password_hash)))
    return res.status(401).json({error:"Invalid username/email or password."});
  if(u.status!=="active") return res.status(403).json({error:"Account is not active."});
  if(!u.email_verified){
    req.session.userId=u.id; req.session.emailVerified=false;
    return res.status(403).json({error:"Verify your email first.",redirect:"/verify-email.html"});
  }
  req.session.userId=u.id; req.session.emailVerified=true;
  res.json({user:safe(u),redirect:"/dashboard.html"});
}

async function me(req,res){
  if(!req.session.userId) return res.status(401).json({error:"Not logged in."});
  const r=await query("SELECT * FROM users WHERE id=$1",[req.session.userId]);
  if(!r.rows[0]) return res.status(401).json({error:"User not found."});
  res.json({user:safe(r.rows[0])});
}

async function logout(req,res){ req.session.destroy(()=>res.json({message:"Logged out."})); }

async function forgotPassword(req,res){
  const email=String(req.body.email||"").trim().toLowerCase();
  const r=await query("SELECT id,email FROM users WHERE email=$1",[email]);
  if(!r.rows[0]) return res.json({message:"If the email exists, a reset link was sent."});
  const token=randomToken(32);
  await query("DELETE FROM password_resets WHERE user_id=$1",[r.rows[0].id]);
  await query(
    "INSERT INTO password_resets(user_id,token_hash,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 minutes')",
    [r.rows[0].id,hash(token)]
  );
  const base=process.env.BASE_URL||`${req.protocol}://${req.get("host")}`;
  await sendPasswordResetEmail(r.rows[0].email,`${base}/reset-password.html?token=${token}`);
  res.json({message:"If the email exists, a reset link was sent."});
}

async function resetPassword(req,res){
  const {token,password,confirmPassword}=req.body;
  if(!token||!password||password!==confirmPassword||password.length<8) return res.status(400).json({error:"Invalid reset details."});
  const r=await query("SELECT * FROM password_resets WHERE token_hash=$1 AND used=false AND expires_at>NOW() LIMIT 1",[hash(token)]);
  if(!r.rows[0]) return res.status(400).json({error:"Reset link invalid or expired."});
  const ph=await bcrypt.hash(password,12);
  await query("UPDATE users SET password_hash=$1,updated_at=NOW() WHERE id=$2",[ph,r.rows[0].user_id]);
  await query("UPDATE password_resets SET used=true WHERE id=$1",[r.rows[0].id]);
  res.json({message:"Password updated.",redirect:"/login.html"});
}

module.exports={register,verifyEmail,resendCode,login,me,logout,forgotPassword,resetPassword};
