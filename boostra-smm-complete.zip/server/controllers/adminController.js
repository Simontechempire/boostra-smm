const {query}=require("../../database/database");
const config=require("../config");

async function login(req,res){
  if(!config.ownerPanelPin) return res.status(500).json({error:"OWNER_PANEL_PIN is not configured."});
  if(String(req.body.pin||"")!==String(config.ownerPanelPin)) return res.status(401).json({error:"Invalid owner PIN."});
  req.session.ownerAuthenticated=true;
  // Owner is not a customer account; payment reviews are audited without a user id.
  req.session.ownerUserId=null;
  res.json({message:"Owner access granted.",redirect:"/admin/dashboard.html"});
}

function logout(req,res){
  req.session.ownerAuthenticated=false;
  req.session.ownerUserId=null;
  res.json({message:"Owner logged out."});
}

async function stats(req,res){
  const users=await query("SELECT COUNT(*)::int count FROM users");
  const orders=await query("SELECT COUNT(*)::int count FROM orders");
  const revenue=await query("SELECT COALESCE(SUM(charge),0) total FROM orders WHERE status IN ('processing','completed')");
  const pending=await query("SELECT COUNT(*)::int count FROM payments WHERE status='pending'");
  res.json({users:users.rows[0].count,orders:orders.rows[0].count,revenue:revenue.rows[0].total,pending:pending.rows[0].count});
}

async function users(req,res){
  const r=await query("SELECT id,username,email,balance,status,email_verified,created_at FROM users ORDER BY created_at DESC LIMIT 500");
  res.json({users:r.rows});
}

async function services(req,res){
  const r=await query("SELECT * FROM services ORDER BY category,name");
  res.json({services:r.rows});
}

module.exports={login,logout,stats,users,services};
