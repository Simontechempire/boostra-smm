const {query}=require("../../database/database");

async function listServices(req,res){
  const r=await query(
    `SELECT id,provider_service_id,name,category,description,rate,min_quantity,max_quantity,refill
     FROM services WHERE active=true ORDER BY category,name`
  );
  res.json({services:r.rows});
}

async function createOrder(req,res){
  const serviceId=Number(req.body.serviceId);
  const quantity=Number(req.body.quantity);
  const link=String(req.body.link||"").trim();
  if(!Number.isInteger(serviceId)||!Number.isInteger(quantity)||!link) return res.status(400).json({error:"Complete the order form."});
  const s=await query("SELECT * FROM services WHERE id=$1 AND active=true",[serviceId]);
  if(!s.rows[0]) return res.status(404).json({error:"Service not found."});
  const service=s.rows[0];
  if(quantity<service.min_quantity||quantity>service.max_quantity)
    return res.status(400).json({error:`Quantity must be between ${service.min_quantity} and ${service.max_quantity}.`});
  const charge=Number((Number(service.rate)*quantity/1000).toFixed(2));
  if(charge<=0) return res.status(400).json({error:"This service has no valid price."});

  // Starter implementation records the order and debits the wallet.
  // Provider dispatch should be enabled only after its exact API contract is verified.
  const bal=await query("SELECT balance FROM users WHERE id=$1",[req.session.userId]);
  if(Number(bal.rows[0].balance)<charge) return res.status(400).json({error:"Insufficient balance."});

  const client=await require("../../database/database").pool.connect();
  try{
    await client.query("BEGIN");
    const b=await client.query("SELECT balance FROM users WHERE id=$1 FOR UPDATE",[req.session.userId]);
    const next=Number(b.rows[0].balance)-charge;
    await client.query("UPDATE users SET balance=$1,updated_at=NOW() WHERE id=$2",[next.toFixed(2),req.session.userId]);
    const ref=`ORD-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
    await client.query(
      "INSERT INTO wallet_transactions(user_id,type,amount,balance_after,reference,description) VALUES($1,'debit',$2,$3,$4,$5)",
      [req.session.userId,charge,next.toFixed(2),ref,"Order charge"]
    );
    const o=await client.query(
      "INSERT INTO orders(user_id,service_id,link,quantity,charge,status) VALUES($1,$2,$3,$4,$5,'pending') RETURNING *",
      [req.session.userId,service.id,link,quantity,charge]
    );
    await client.query("COMMIT");
    res.json({message:"Order created and is pending provider processing.",order:o.rows[0]});
  }catch(e){
    await client.query("ROLLBACK");
    console.error(e);
    res.status(500).json({error:"Could not create order."});
  }finally{client.release();}
}

async function listOrders(req,res){
  const r=await query(
    `SELECT o.*,s.name service_name FROM orders o
     LEFT JOIN services s ON s.id=o.service_id
     WHERE o.user_id=$1 ORDER BY o.created_at DESC LIMIT 100`,
    [req.session.userId]
  );
  res.json({orders:r.rows});
}

module.exports={listServices,createOrder,listOrders};
