const {query}=require("../../database/database");
const crypto=require("crypto");

async function createPayment(req,res){
  const amount=Number(req.body.amount);
  if(!Number.isFinite(amount)||amount<=0) return res.status(400).json({error:"Enter a valid amount."});
  const reference=`PAY-${Date.now()}-${crypto.randomBytes(3).toString("hex")}`;
  const r=await query(
    "INSERT INTO payments(user_id,amount,method,reference) VALUES($1,$2,'PalmPay',$3) RETURNING *",
    [req.session.userId,amount,reference]
  );
  res.json({
    payment:r.rows[0],
    instructions:{bank:"PalmPay",accountName:"Oghenerouna Emeri",accountNumber:"8071569915"}
  });
}

async function wallet(req,res){
  const b=await query("SELECT balance FROM users WHERE id=$1",[req.session.userId]);
  const t=await query(
    "SELECT type,amount,balance_after,reference,description,created_at FROM wallet_transactions WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50",
    [req.session.userId]
  );
  res.json({balance:b.rows[0]?.balance||0,transactions:t.rows});
}

module.exports={createPayment,wallet};
