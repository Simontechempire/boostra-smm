const express=require("express");
const c=require("../controllers/walletController");
const {requireVerified}=require("../middleware/auth");
const router=express.Router();
router.get("/",requireVerified,c.wallet);
module.exports=router;
