const express=require("express");
const c=require("../controllers/orderController");
const {requireVerified}=require("../middleware/auth");
const router=express.Router();
router.get("/services",requireVerified,c.listServices);
router.post("/",requireVerified,c.createOrder);
router.get("/",requireVerified,c.listOrders);
module.exports=router;
