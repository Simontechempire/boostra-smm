const express=require("express");
const c=require("../controllers/walletController");
const {requireVerified}=require("../middleware/auth");
const router=express.Router();
router.post("/",requireVerified,c.createPayment);
module.exports=router;
