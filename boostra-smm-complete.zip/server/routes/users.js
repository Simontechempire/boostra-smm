const express=require("express");
const {requireVerified}=require("../middleware/auth");
const {query}=require("../../database/database");
const router=express.Router();
router.get("/me",requireVerified,async(req,res)=>{
  const r=await query("SELECT id,username,email,first_name,last_name,whatsapp,balance,referral_code,status FROM users WHERE id=$1",[req.session.userId]);
  res.json({user:r.rows[0]});
});
module.exports=router;
