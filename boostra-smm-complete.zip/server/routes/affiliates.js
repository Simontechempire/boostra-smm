const express=require("express");
const {query}=require("../../database/database");
const {requireVerified}=require("../middleware/auth");
const router=express.Router();
router.get("/",requireVerified,async(req,res)=>{
  const u=await query("SELECT referral_code FROM users WHERE id=$1",[req.session.userId]);
  const r=await query(
    "SELECT COUNT(*)::int total,COALESCE(SUM(reward),0) rewards FROM referrals WHERE referrer_id=$1",
    [req.session.userId]
  );
  res.json({referralCode:u.rows[0]?.referral_code,total:r.rows[0]?.total||0,rewards:r.rows[0]?.rewards||0});
});
module.exports=router;
