const express=require("express");
const c=require("../controllers/orderController");
const {requireVerified}=require("../middleware/auth");
const router=express.Router();
router.get("/",requireVerified,c.listServices);
module.exports=router;
