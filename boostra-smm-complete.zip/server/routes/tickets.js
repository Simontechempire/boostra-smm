const express=require("express");
const {query}=require("../../database/database");
const {requireVerified}=require("../middleware/auth");
const router=express.Router();
router.get("/",requireVerified,async(req,res)=>{
  const r=await query("SELECT * FROM tickets WHERE user_id=$1 ORDER BY created_at DESC",[req.session.userId]);
  res.json({tickets:r.rows});
});
router.post("/",requireVerified,async(req,res)=>{
  const subject=String(req.body.subject||"").trim();
  const message=String(req.body.message||"").trim();
  if(!subject||!message) return res.status(400).json({error:"Subject and message are required."});
  const r=await query("INSERT INTO tickets(user_id,subject,message) VALUES($1,$2,$3) RETURNING *",[req.session.userId,subject,message]);
  res.json({ticket:r.rows[0]});
});
module.exports=router;
