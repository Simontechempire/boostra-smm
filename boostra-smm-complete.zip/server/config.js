require("dotenv").config();

module.exports = {
  port: Number(process.env.PORT || 10000),
  databaseUrl: process.env.DATABASE_URL,
  sessionSecret: process.env.SESSION_SECRET || "change-me",
  jwtSecret: process.env.JWT_SECRET || "change-me",
  ownerPanelPin: process.env.OWNER_PANEL_PIN || "",
  ownerEmail: process.env.OWNER_EMAIL || "",
  smtp: {
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: String(process.env.SMTP_SECURE).toLowerCase() === "true",
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    from: process.env.MAIL_FROM || process.env.SMTP_USER
  },
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackUrl: process.env.GOOGLE_CALLBACK_URL
  },
  famsup: {
    apiUrl: process.env.FAMSUP_API_URL || "https://famsup.com/api/v2",
    apiKey: process.env.FAMSUP_API_KEY || ""
  },
  telegram: {
    token: process.env.TELEGRAM_BOT_TOKEN || "",
    ownerId: process.env.OWNER_TELEGRAM_ID || ""
  },
  payment: {
    bank: "PalmPay",
    accountName: "Oghenerouna Emeri",
    accountNumber: "8071569915"
  }
};
