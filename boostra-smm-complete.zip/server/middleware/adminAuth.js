function requireOwner(req,res,next) {
  if (!req.session.ownerAuthenticated) return res.status(401).json({error:"Owner authentication required."});
  next();
}
module.exports = {requireOwner};
