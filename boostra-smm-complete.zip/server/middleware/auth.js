function requireAuth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:"Authentication required."});
  next();
}
function requireVerified(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:"Authentication required."});
  if (!req.session.emailVerified) return res.status(403).json({error:"Please verify your email first."});
  next();
}
module.exports = {requireAuth,requireVerified};
