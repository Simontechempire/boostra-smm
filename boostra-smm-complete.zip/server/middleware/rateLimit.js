const rateLimit = require("express-rate-limit");
const authLimiter = rateLimit({
  windowMs:15*60*1000,
  max:30,
  standardHeaders:true,
  legacyHeaders:false,
  message:{error:"Too many requests. Try again later."}
});
module.exports = {authLimiter};
