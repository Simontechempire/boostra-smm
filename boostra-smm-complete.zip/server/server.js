require("dotenv").config();
const express=require("express");
const path=require("path");
const helmet=require("helmet");
const session=require("express-session");
const PgSession=require("connect-pg-simple")(session);
const config=require("./config");
const {pool,initDb}=require("../database/database");

const app=express();

app.set("trust proxy",1);
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:true}));
app.use(session({
  store:new PgSession({pool,tableName:"user_sessions",createTableIfMissing:true}),
  secret:config.sessionSecret,
  resave:false,
  saveUninitialized:false,
  cookie:{
    httpOnly:true,
    sameSite:"lax",
    secure:process.env.NODE_ENV==="production",
    maxAge:1000*60*60*24*7
  }
}));

app.get("/health",(req,res)=>res.json({status:"ok",service:"Boostra SMM"}));

app.use("/api/auth",require("./routes/auth"));
app.use("/api/users",require("./routes/users"));
app.use("/api/orders",require("./routes/orders"));
app.use("/api/services",require("./routes/services"));
app.use("/api/wallet",require("./routes/wallet"));
app.use("/api/payments",require("./routes/payments"));
app.use("/api/affiliates",require("./routes/affiliates"));
app.use("/api/tickets",require("./routes/tickets"));
app.use("/api/admin",require("./routes/admin"));

app.use(express.static(path.join(__dirname,"..","public")));
app.use("/admin",express.static(path.join(__dirname,"..","admin")));

app.get("/",(req,res)=>res.sendFile(path.join(__dirname,"..","public","index.html")));

initDb()
  .then(()=>{
    app.listen(config.port,()=>console.log(`Boostra running on port ${config.port}`));
    if(config.telegram.token) require("../telegram/bot");
  })
  .catch(err=>{
    console.error("Database startup failed:",err);
    process.exit(1);
  });
