const crypto = require("crypto");

function verificationCode() {
  return String(crypto.randomInt(100000, 1000000));
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString("hex");
}

function hash(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

module.exports = { verificationCode, randomToken, hash };
