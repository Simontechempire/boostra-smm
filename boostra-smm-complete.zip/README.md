# Boostra SMM

Render-ready customer panel + owner dashboard.

## Run
1. Create a Render PostgreSQL database.
2. Put its Internal Database URL in DATABASE_URL.
3. Set values from .env.example in Render Environment Variables.
4. Build: npm install
5. Start: npm start

Email verification requires SMTP credentials.
Google sign-in is optional.
Owner panel requires OWNER_PANEL_PIN.

The provider adapter is intentionally isolated in server/services/famsupService.js.
Use the exact provider documentation/account contract before enabling real provider orders.
