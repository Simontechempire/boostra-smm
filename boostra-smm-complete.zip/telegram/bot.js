const https=require("https");
const config=require("../server/config");

if(!config.telegram.token){
  console.log("[telegram] Disabled: TELEGRAM_BOT_TOKEN not configured.");
  module.exports={};
}else{
  console.log("[telegram] Optional owner notification bot enabled.");
  // This starter intentionally keeps Telegram optional and does not expose
  // customer credentials or owner PINs through Telegram.
}
